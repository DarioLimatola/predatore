from .predatore_native import *

__doc__ = predatore_native.__doc__
if hasattr(predatore_native, "__all__"):
    __all__ = predatore_native.__all__